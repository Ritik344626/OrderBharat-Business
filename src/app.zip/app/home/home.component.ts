import { Component, HostListener, OnInit } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { TokenService } from "../Services/token.service";
import MessagingserviceComponent from "../messagingservice/messagingservice.component";
//import { environment } from '../environments/environment';
import { environment } from "../../environments/environment";
// import { IonRouterOutlet, Platform } from '@ionic/angular';
// import { Plugins } from '@capacitor/core';
// const { App } = Plugins;

declare var $: any;

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"],
})
export class HomeComponent implements OnInit {
  bnm: any;
  constructor(
    private Token: TokenService,
    private httpclient: HttpClient,
    private router: Router,
    private Messagingservice: MessagingserviceComponent // private platform: Platform, // private routerOutlet: IonRouterOutlet
  ) {
    // this.platform.backButton.subscribeWithPriority(-1, () => {
    //   // if (!this.routerOutlet.canGoBack()) {
    //   //   App.exitApp();
    //   // }
    //   App.exitApp();
    // });
  }

  response: any;
  auth: any = false;
  otherdata: any = [];
  customerdata: any = [];
  yougive: any = [];

  businessdetails: any = [];
  user_id: any;
  company_id: any;

  lastcusid: any;
  customerloadlimit: any;

  //loader indicator
  loaded = false;

  // prev_pageYOffset: any = 0;

  ngOnInit(): void {
    if (
      localStorage.getItem("user_id") == "" ||
      localStorage.getItem("user_id") == null
    ) {
      this.router.navigate(["/"]);
    }
    this.user_id = localStorage.getItem("user_id");
    this.company_id = localStorage.getItem("company_id");

    this.getshopdetails();
    this.getallcustomer();
    // this.presentLoading();
    this.auth = true;
    // this.Messagingservice.gettoken();
  }

  getallcustomer() {
    if ($(window).height() <= 600) {
      this.customerloadlimit = 5;
    }

    this.httpclient
      .post(environment.apiBaseUrl + "getallcustomer", [
        {
          api_key: environment.apikey,
          user_id: this.user_id,
          company_id: this.company_id,
          customerloadlimit: this.customerloadlimit,
        },
      ])
      .subscribe((res: any) => {
        this.response = res;
        this.loaded = true;

        if (this.response.success == true) {
          this.customerdata = this.response.data.customerdata;
          //  this.yougive = this.response.data.yougive;
          // for (var i = 0; i < this.customerdata.length; i++) {
          //   this.lastcusid = this.customerdata[i].customer_id;
          // }
        } else if (this.response.success == false) {
          // Swal.fire({
          //   title: 'Oops...',
          //   text: this.response.data.message,
          //   icon: 'warning',
          //   confirmButtonText: 'Ok',
          // });
        }
      });
  }

  editcustomer(id: any) {
    localStorage.setItem("customer_id", id);
    this.router.navigate(["/editcustomer"]);
  }

  customer(id: any) {
    localStorage.setItem("customer_id", id);
    this.router.navigate(["/customer"]);
  }

  editprofile() {
    this.router.navigate(["/editprofile"]);
  }

  subscription() {
    this.router.navigateByUrl("/subscription");
  }

  // presentLoading() {
  //   this.subscription = this.platform.backButton.subscribeWithPriority(
  //     9999,
  //     () => {
  //       // do nothing
  //     }
  //   );

  //   this.subscription.unsubscribe();

  //   // const loading = await this.loadingController
  //   //   .create({
  //   //     spinner: 'circles',
  //   //     keyboardClose: true,
  //   //     message: 'Please Wait',
  //   //   })
  //   //   .then((res) => {
  //   //     res.onDidDismiss().then((d) => {
  //   //       this.platform.backButton.observers.pop();
  //   //     });
  //   //     return res.present();
  //   //   });
  //   // return loading;
  // }

  getshopdetails() {
    console.log(this.company_id);

    this.httpclient
      .post(environment.apiBaseUrl + "getshopdetails", [
        {
          api_key: environment.apikey,
          user_id: this.user_id,
          company_id: this.company_id,
        },
      ])
      .subscribe((res: any) => {
        this.response = res;

        if (this.response.success == true) {
          this.otherdata = this.response.data;
          this.businessdetails = this.response.data.businessdetails;
          if (this.businessdetails.name.length > 20) {
            this.bnm = this.businessdetails.name.substring(0, 20);
          } else {
            this.bnm = this.businessdetails.name;
          }
        } else if (this.response.success == false) {
          Swal.fire({
            title: "Oops...",
            text: this.response.data.message,
            icon: "warning",
            confirmButtonText: "Ok",
          });
        }
      });
  }
  searchcustomer(data: any) {
    this.httpclient
      .post(environment.apiBaseUrl + "searchcustomerbyname", [
        {
          api_key: environment.apikey,
          user_id: this.user_id,
          company_id: this.company_id,
          customername: data.target.value,
          customerloadlimit: this.customerloadlimit,
        },
      ])
      .subscribe((res: any) => {
        this.response = res;

        if (this.response.success == true) {
          this.customerdata = this.response.data.customerdata;

          // for (var i = 0; i < this.customerdata.length; i++) {
          //   this.lastcusid = this.customerdata[i].customer_id;
          // }
        } else if (this.response.success == false) {
          Swal.fire({
            title: "Oops...",
            text: this.response.data.message,
            icon: "warning",
            confirmButtonText: "Ok",
          });
        }
      });
  }

  @HostListener("window:scroll", ["$event"])
  getScrollPos(data: any) {
    var curr_pageYOffset = Math.floor(data.path[1].pageYOffset);

    if (curr_pageYOffset == $(document).height() - $(window).height()) {
      // ajax call get data from server and append to the div
      this.customerloadlimit += 5;
      this.httpclient
        .post(environment.apiBaseUrl + "getallcustomer", [
          {
            api_key: environment.apikey,
            user_id: this.user_id,
            company_id: this.company_id,
            // lastcusid: this.lastcusid,
            customerloadlimit: this.customerloadlimit,
          },
        ])
        .subscribe((res: any) => {
          this.response = res;

          if (this.response.success == true) {
            console.log(this.response.data.yougive);

            this.customerdata = this.response.data.customerdata;

            // for (var i = 0; i < this.customerdata.length; i++) {
            //   this.lastcusid = this.customerdata[i].customer_id;
            // }
          } else if (this.response.success == false) {
            Swal.fire({
              title: "Oops...",
              text: this.response.data.message,
              icon: "warning",
              confirmButtonText: "Ok",
            });
          }
        });
    }

    // if (this.prev_pageYOffset < curr_pageYOffset) {
    //   this.prev_pageYOffset = curr_pageYOffset;
    //   console.log('Current position: ' + curr_pageYOffset);
    // }

    // if (this.prev_pageYOffset == curr_pageYOffset) {
    //   console.log('Load New');
    // }
  }
}
