import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentlist',
  templateUrl: './paymentlist.component.html',
  styleUrls: ['./paymentlist.component.scss']
})
export class PaymentlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
