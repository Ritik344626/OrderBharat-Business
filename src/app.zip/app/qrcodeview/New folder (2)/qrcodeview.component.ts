//import { SocialSharing } from '@awesome-cordova-plugins/social-sharing';
import { Encoding } from "@capacitor/filesystem";

