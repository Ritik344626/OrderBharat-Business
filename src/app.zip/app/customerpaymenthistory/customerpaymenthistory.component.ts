import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerpaymenthistory',
  templateUrl: './customerpaymenthistory.component.html',
  styleUrls: ['./customerpaymenthistory.component.scss']
})
export class CustomerpaymenthistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
