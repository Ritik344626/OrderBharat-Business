import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createorder',
  templateUrl: './createorder.component.html',
  styleUrls: ['./createorder.component.scss'],
})
export class CreateorderComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
