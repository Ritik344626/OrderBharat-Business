import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editaddress',
  templateUrl: './editaddress.component.html',
  styleUrls: ['./editaddress.component.scss'],
})
export class EditaddressComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
