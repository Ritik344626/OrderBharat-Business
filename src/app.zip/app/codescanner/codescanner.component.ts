import { Component, OnInit } from '@angular/core';

//import { BarcodeScanner } from '@awesome-cordova-plugins/barcode-scanner/ngx';

@Component({
  selector: 'app-codescanner',
  templateUrl: './codescanner.component.html',
  styleUrls: ['./codescanner.component.scss'],
})
export class CodescannerComponent {
//  constructor(//private barcodeScanner: BarcodeScanner) {}

  // scan() {
  //   this.barcodeScanner.scan().then((barcodeData: any) => {
  //     return barcodeData.text;
  //   });
  // }
}
