import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scaninvoice',
  templateUrl: './scaninvoice.component.html',
  styleUrls: ['./scaninvoice.component.scss'],
})
export class ScaninvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
