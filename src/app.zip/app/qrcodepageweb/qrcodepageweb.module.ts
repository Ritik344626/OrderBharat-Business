import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { QrcodepagePageRoutingModule } from './qrcodepage-routing.module';

import { QrcodepagePage } from './qrcodepage.page';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    QrcodepagePageRoutingModule,
  ],
  providers: [
  ]
  //declarations: [QrcodepagePage]
})
export class QrcodepagePageModule { }
