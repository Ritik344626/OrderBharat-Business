import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shortinfo',
  templateUrl: './shortinfo.component.html',
  styleUrls: ['./shortinfo.component.scss'],
})
export class ShortinfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
